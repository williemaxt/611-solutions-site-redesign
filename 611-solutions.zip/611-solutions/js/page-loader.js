
function openWebElement(){

  $('#cost-analysis').load('../611-solutions/elements/web-analysis.html');
  $('#open_web_btn').hide();

}
